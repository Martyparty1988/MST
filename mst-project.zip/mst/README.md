# 🌟 MST - Marty Solar Tracker

Professional time tracking application for solar panel installation.

## 🚀 Quick Start

```bash
npm install
npm run dev
```

## 📦 Build

```bash
npm run build
```

## 🔐 Admin Access

5× click on logo within 3 seconds
Default password: `mst2025`

## 🎯 Features

✅ Worker management
✅ Time tracking
✅ PDF plan viewer
✅ Statistics & reports
✅ Admin dashboard
✅ Offline PWA support
