export interface Worker {
  id: string;
  name: string;
  code: string;
  hourlyRate: number;
  color: string;
}

export interface Project {
  id: string;
  name: string;
  createdAt: number;
}

export interface WorkEntry {
  id: string;
  type: 'task' | 'hourly';
  timestamp: number;
  projectId?: string;
  workerId?: string;
  workers?: { workerId: string; workerCode: string }[];
  tableNumber?: string;
  rewardPerWorker?: number;
  totalHours?: number;
  totalEarned?: number;
}

export interface AppState {
  workers: Worker[];
  projects: Project[];
  workEntries: WorkEntry[];
}
