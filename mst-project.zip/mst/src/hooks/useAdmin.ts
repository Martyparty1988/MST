import { useState, useEffect } from 'react';
import { AdminService } from '../services/admin.service';

export const useAdmin = () => {
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    setIsAdmin(AdminService.isLoggedIn());
  }, []);

  const login = (password: string): boolean => {
    const success = AdminService.login(password);
    setIsAdmin(success);
    return success;
  };

  const logout = () => {
    AdminService.logout();
    setIsAdmin(false);
  };

  const checkAccess = (): boolean => {
    if (AdminService.checkAccess()) {
      setIsAdmin(true);
      return true;
    }
    return false;
  };

  return { isAdmin, login, logout, checkAccess };
};
