import React from 'react';

export const StatsPage: React.FC = () => {
  return <div className="page"><h1>📊 Statistiky</h1></div>;
};
