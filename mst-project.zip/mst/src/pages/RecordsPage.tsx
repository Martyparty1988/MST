import React from 'react';

export const RecordsPage: React.FC = () => {
  return <div className="page"><h1>📝 Záznamy</h1></div>;
};
