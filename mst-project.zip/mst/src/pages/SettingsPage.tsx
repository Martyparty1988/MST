import React from 'react';

export const SettingsPage: React.FC = () => {
  return <div className="page"><h1>⚙️ Nastavení</h1></div>;
};
