import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdmin } from '../hooks/useAdmin';
import { StorageService } from '../services/storage.service';
import { AdminService } from '../services/admin.service';

export const AdminPage: React.FC = () => {
  const { isAdmin, logout } = useAdmin();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAdmin) navigate('/');
  }, [isAdmin, navigate]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleExport = () => {
    const data = StorageService.export();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mst-backup-${Date.now()}.json`;
    a.click();
  };

  return (
    <div className="page admin-page">
      <div className="admin-header">
        <h1>🔐 Admin Dashboard</h1>
        <button onClick={handleLogout} className="btn-danger">Odhlásit</button>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div>💰</div>
          <h3>Výdělky</h3>
        </div>
      </div>

      <button onClick={handleExport} className="btn-primary">📥 Export dat</button>

      <div className="system-info">
        <p>Session: {AdminService.getSessionTime()}</p>
        <p>Velikost dat: {StorageService.getDataSize()}</p>
      </div>
    </div>
  );
};
