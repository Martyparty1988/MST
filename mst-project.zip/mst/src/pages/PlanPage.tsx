import React from 'react';

export const PlanPage: React.FC = () => {
  return <div className="page"><h1>📋 Plán</h1><p>PDF viewer bude zde</p></div>;
};
