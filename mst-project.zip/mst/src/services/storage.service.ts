import { AppState } from '../types';

const STORAGE_KEY = 'mstAppState';

export class StorageService {
  static save(state: AppState): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  static load(): AppState {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) {
      return { workers: [], projects: [], workEntries: [] };
    }
    return JSON.parse(data);
  }

  static export(): string {
    const state = this.load();
    return JSON.stringify(state, null, 2);
  }

  static getDataSize(): string {
    const data = localStorage.getItem(STORAGE_KEY) || '';
    const bytes = new Blob([data]).size;
    return `${(bytes / 1024).toFixed(2)} KB`;
  }
}
