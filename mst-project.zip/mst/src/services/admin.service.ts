const ADMIN_PASSWORD = 'mst2025';
const ADMIN_SESSION_KEY = 'mstAdminAuth';
const SESSION_DURATION = 8 * 60 * 60 * 1000;

export class AdminService {
  static isLoggedIn(): boolean {
    const sessionStr = localStorage.getItem(ADMIN_SESSION_KEY);
    if (!sessionStr) return false;

    try {
      const { timestamp } = JSON.parse(sessionStr);
      const elapsed = Date.now() - timestamp;
      return elapsed < SESSION_DURATION;
    } catch {
      return false;
    }
  }

  static login(password: string): boolean {
    if (password === ADMIN_PASSWORD) {
      localStorage.setItem(
        ADMIN_SESSION_KEY,
        JSON.stringify({ timestamp: Date.now(), role: 'admin' })
      );
      return true;
    }
    return false;
  }

  static logout(): void {
    localStorage.removeItem(ADMIN_SESSION_KEY);
  }

  static promptLogin(): boolean {
    const password = prompt('🔐 Admin heslo:');
    if (!password) return false;

    if (this.login(password)) {
      return true;
    } else {
      alert('❌ Nesprávné heslo!');
      return false;
    }
  }

  static checkAccess(): boolean {
    if (this.isLoggedIn()) return true;
    return this.promptLogin();
  }

  static getSessionTime(): string {
    const sessionStr = localStorage.getItem(ADMIN_SESSION_KEY);
    if (!sessionStr) return '-';

    try {
      const { timestamp } = JSON.parse(sessionStr);
      const elapsed = Date.now() - timestamp;
      const hours = Math.floor(elapsed / (1000 * 60 * 60));
      const minutes = Math.floor((elapsed % (1000 * 60 * 60)) / (1000 * 60));
      return `${hours}h ${minutes}m`;
    } catch {
      return '-';
    }
  }
}
