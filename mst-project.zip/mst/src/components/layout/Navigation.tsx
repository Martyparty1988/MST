import React from 'react';
import { NavLink } from 'react-router-dom';

export const Navigation: React.FC = () => {
  return (
    <nav className="bottom-nav">
      <NavLink to="/" className="nav-item">📋 Plán</NavLink>
      <NavLink to="/records" className="nav-item">📝 Záznamy</NavLink>
      <NavLink to="/stats" className="nav-item">📊 Statistiky</NavLink>
      <NavLink to="/settings" className="nav-item">⚙️ Nastavení</NavLink>
    </nav>
  );
};
