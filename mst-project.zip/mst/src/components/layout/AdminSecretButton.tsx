import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdmin } from '../../hooks/useAdmin';

export const AdminSecretButton: React.FC = () => {
  const [tapCount, setTapCount] = useState(0);
  const timerRef = useRef<number>();
  const navigate = useNavigate();
  const { checkAccess } = useAdmin();

  const handleLogoClick = () => {
    setTapCount((prev) => prev + 1);
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => setTapCount(0), 3000);
  };

  useEffect(() => {
    if (tapCount >= 5) {
      setTapCount(0);
      if (checkAccess()) navigate('/admin');
    }
  }, [tapCount, checkAccess, navigate]);

  return (
    <div onClick={handleLogoClick} style={{ cursor: 'pointer', userSelect: 'none' }}>
      <h1 className="logo">☀️ MST</h1>
    </div>
  );
};
