import React from 'react';
import { AdminSecretButton } from './AdminSecretButton';

export const Header: React.FC = () => {
  return (
    <header className="header">
      <AdminSecretButton />
      <div className="header-version">v1.0</div>
    </header>
  );
};
